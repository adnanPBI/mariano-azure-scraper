# Credentials, evidence handling and authorization limits

- The source tree is the git-tracked tree at `d09b7498903daebe60cb31420d8012682cb05e75`; there are no runtime .env files, account passwords, private keys, session cookies, Azure tokens, authenticated HARs or API secrets in the archive.
- Configuration examples are included because they are tracked source: `source/.env.example`, `source/config/stores.yaml.example`, `source/release/authorization_metadata.example.json`, `source/release/observed_acceptance.example.json` and `source/pyproject.toml`.
- GitHub Actions logs were fetched directly from previously completed run 41781451562. Automatic high-risk credential patterns were inspected for redaction; no matching substitution was needed. Logs should still be handled as review evidence, not retailer data.
- CI outputs on this commit use local or synthetic fixtures. A successful job doesn't authorize running the scraper, enrolling a new Mariano's contest entry, or spending money in Azure/Oxylabs.
- No fresh CI jobs, product browsing, live collection, paid API diagnostic, Azure deployment, retailer requests, or software-package rebuild were performed while assembling this bundle.
- Preserve all existing evidence-domain statuses, including contest eligibility as **separately unresolved**. No new Mariano's entry or award commitment.
- Walmart's pending one-request / zero-retry Classic diagnostic remains completely untouched; 90-second phase and 2,000,000-byte limits remain authoritative if separately approved in the future.
- Source qualification requires the client-authorized Vernon Hills/PICKUP return path and source-bound price response, not a directory label or a normalized synthetic fixture.
- Sha256 manifest certifies files in this handoff, not truthfulness of external source claims. Official CI and source records remain independently viewable at their GitHub URLs.
